import React from 'react';

interface VenueModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VenueModal: React.FC<VenueModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#303033]/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-[#ccc4ce]/40 overflow-hidden">
        {/* Header */}
        <div className="p-6 bg-[#fbf8fc] border-b border-[#ccc4ce]/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase tracking-[0.2em] text-[#6a5581] font-semibold block mb-0.5">
              Location &amp; Arrival
            </span>
            <h3 className="font-headline text-2xl text-[#1b1b1e]">
              The Glasshouse Conservatory
            </h3>
          </div>
          <button
            onClick={onClose}
            aria-label="Close venue details"
            className="w-8 h-8 rounded-full bg-[#f5f3f7] hover:bg-[#e9e7eb] flex items-center justify-center text-[#4a454d] transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">close</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs text-[#4a454d]">
          {/* Address & GPS */}
          <div className="bg-[#f5f3f7] rounded-xl p-4 border border-[#ccc4ce]/30 space-y-2">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="font-semibold text-sm text-[#1b1b1e]">
                  The Glasshouse Conservatory &amp; Gardens
                </h4>
                <p className="text-xs text-[#4a454d]">
                  480 Route 9D, Cold Spring, Hudson Valley, NY 10516
                </p>
              </div>
              <span className="font-mono text-[11px] text-[#6a5581] bg-[#efdbff]/50 px-2 py-0.5 rounded">
                41.5033° N, 73.9575° W
              </span>
            </div>
            <div className="pt-2 flex gap-3">
              <a
                href="https://maps.google.com/?q=The+Glasshouse+Cold+Spring+NY"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#6a5581] font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Open in Google Maps</span>
                <span className="material-symbols-outlined text-[14px]">open_in_new</span>
              </a>
              <a
                href="https://maps.apple.com/?q=The+Glasshouse+Cold+Spring+NY"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#6a5581] font-semibold hover:underline inline-flex items-center gap-1"
              >
                <span>Open in Apple Maps</span>
                <span className="material-symbols-outlined text-[14px]">open_in_new</span>
              </a>
            </div>
          </div>

          {/* Valet & Parking */}
          <div className="space-y-1.5">
            <h5 className="font-semibold text-xs uppercase tracking-wider text-[#1b1b1e] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#6a5581] text-[16px]">local_parking</span>
              <span>Complimentary Valet Service</span>
            </h5>
            <p className="leading-relaxed">
              Complimentary valet attendants will greet all arriving guests at the Main Conservatory gates starting promptly at <strong>4:00 PM EDT</strong>. Self-parking is also available in the paved West Garden lot.
            </p>
          </div>

          {/* Train directions */}
          <div className="space-y-1.5">
            <h5 className="font-semibold text-xs uppercase tracking-wider text-[#1b1b1e] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#6a5581] text-[16px]">train</span>
              <span>Metro-North Hudson Line from NYC</span>
            </h5>
            <p className="leading-relaxed">
              Depart from <strong>Grand Central Terminal</strong> to <strong>Cold Spring Station</strong>. The journey takes approximately 70 minutes with sweeping views of the Hudson River Palisades. Local taxis and Lyft/Uber are stationed outside the platform for the 5-minute drive to the venue.
            </p>
          </div>

          {/* Driving from NYC & CT */}
          <div className="space-y-1.5">
            <h5 className="font-semibold text-xs uppercase tracking-wider text-[#1b1b1e] flex items-center gap-1.5">
              <span className="material-symbols-outlined text-[#6a5581] text-[16px]">directions_car</span>
              <span>Driving Routes</span>
            </h5>
            <p className="leading-relaxed">
              <strong>From Manhattan:</strong> Take the Henry Hudson Parkway north to the Saw Mill River Parkway, then connect to the Taconic State Parkway north. Exit at Route 301 toward Cold Spring, turning south onto Route 9D.
            </p>
            <p className="leading-relaxed">
              <strong>From Connecticut:</strong> Follow I-84 West across the Hudson or take Route 6 to Route 9D North through Garrison into Cold Spring.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-[#ccc4ce]/30 bg-[#fbf8fc] text-right">
          <button
            onClick={onClose}
            type="button"
            className="px-4 py-2 bg-[#6a5581] text-white rounded-lg text-xs uppercase tracking-wider font-semibold hover:bg-[#846d9b] transition-colors cursor-pointer"
          >
            Got It
          </button>
        </div>
      </div>
    </div>
  );
};
