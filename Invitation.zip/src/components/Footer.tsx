import React from 'react';

interface FooterProps {
  onOpenRegistry: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenRegistry }) => {
  return (
    <footer className="w-full bg-[#f5f3f7] border-t border-[#ccc4ce]/30 py-12">
      <div className="max-w-4xl mx-auto px-6 text-center space-y-4">
        <div className="font-headline text-2xl text-[#6a5581] font-normal tracking-wide">
          Nadun &amp; Chathurika
        </div>
        <p className="font-headline text-sm italic text-[#4a454d] max-w-md mx-auto">
          Together with their families, joyfully invite you to celebrate their engagement and future together.
        </p>
        <div className="flex items-center justify-center gap-3 py-1">
          <div className="h-[1px] w-8 bg-[#846d9b]/40"></div>
          <span className="material-symbols-outlined text-[#6a5581] text-[18px]">favorite</span>
          <div className="h-[1px] w-8 bg-[#846d9b]/40"></div>
        </div>
        <div className="text-xs text-[#4a454d] space-y-1">
          <p className="font-semibold text-[#1b1b1e] uppercase tracking-widest">
            Saturday, September 20, 2025
          </p>
          <p>The Glasshouse • Hudson Valley, New York</p>
          <p className="text-[#6a5581] pt-1 font-medium">
            Inquiries:{' '}
            <a
              href="mailto:rsvp@nadunandchathurika.com"
              className="hover:underline"
            >
              rsvp@nadunandchathurika.com
            </a>
          </p>
        </div>

        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3 text-[11px] uppercase tracking-widest text-[#7b757e]">
          <span>© 2025 Nadun &amp; Chathurika • All Rights Reserved</span>
          <span className="hidden sm:inline">·</span>
          <button
            onClick={onOpenRegistry}
            type="button"
            className="hover:text-[#6a5581] transition-colors underline cursor-pointer"
          >
            Organizer Registry Access
          </button>
        </div>
      </div>
    </footer>
  );
};
