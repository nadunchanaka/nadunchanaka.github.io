export const EVENT_DETAILS = {
  title: "Nadun & Chathurika's Engagement Celebration",
  description: "Formal celebration of Nadun & Chathurika's engagement and upcoming union with champagne, sunset hors d'oeuvres, dinner, and dancing under the glass conservatory. Complimentary valet at 4:00 PM EDT.",
  location: "The Glasshouse, 480 Route 9D, Cold Spring, Hudson Valley, NY 10516",
  startTime: "20250920T203000Z", // 4:30 PM EDT in UTC
  endTime: "20250921T030000Z",   // 11:00 PM EDT in UTC
  startDateFormatted: "Saturday, September 20, 2025",
  timeFormatted: "4:30 PM EDT"
};

export function getGoogleCalendarUrl(): string {
  const url = new URL("https://calendar.google.com/calendar/render");
  url.searchParams.set("action", "TEMPLATE");
  url.searchParams.set("text", EVENT_DETAILS.title);
  url.searchParams.set("dates", `${EVENT_DETAILS.startTime}/${EVENT_DETAILS.endTime}`);
  url.searchParams.set("details", EVENT_DETAILS.description);
  url.searchParams.set("location", EVENT_DETAILS.location);
  return url.toString();
}

export function downloadIcsFile(): void {
  const icsContent = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//Nadun and Chathurika//Engagement RSVP//EN",
    "CALSCALE:GREGORIAN",
    "METHOD:PUBLISH",
    "BEGIN:VEVENT",
    `SUMMARY:${EVENT_DETAILS.title}`,
    `DESCRIPTION:${EVENT_DETAILS.description}`,
    `LOCATION:${EVENT_DETAILS.location}`,
    `DTSTART:${EVENT_DETAILS.startTime}`,
    `DTEND:${EVENT_DETAILS.endTime}`,
    `DTSTAMP:${new Date().toISOString().replace(/[-:]/g, "").split(".")[0]}Z`,
    `UID:nadun-chathurika-engagement-20250920@glasshouse`,
    "STATUS:CONFIRMED",
    "SEQUENCE:0",
    "END:VEVENT",
    "END:VCALENDAR"
  ].join("\r\n");

  const blob = new Blob([icsContent], { type: "text/calendar;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.setAttribute("download", "Nadun_and_Chathurika_Engagement.ics");
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
