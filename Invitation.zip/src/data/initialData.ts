import { GuestRsvp, GuestbookNote } from '../types';

export const INITIAL_GUESTS: GuestRsvp[] = [
  {
    id: 'guest-1',
    names: 'Kasun Wickramasinghe & Dilini Silva',
    email: 'kasun.w@example.com',
    status: 'accept',
    partySize: 2,
    dietary: ['Vegetarian'],
    message: 'We are thrilled to celebrate with you both! Sending our deepest blessings for this wonderful journey.',
    createdAt: '2025-07-12T14:20:00Z'
  },
  {
    id: 'guest-2',
    names: 'Dr. Rohan & Anoma Senanayake',
    email: 'rohan.senanayake@example.com',
    status: 'accept',
    partySize: 2,
    dietary: ['Gluten-Free', 'Dairy-Free'],
    message: 'Warmest congratulations Nadun and Chathurika. May your love grow stronger each passing day.',
    createdAt: '2025-07-14T09:15:00Z'
  },
  {
    id: 'guest-3',
    names: 'Saman Jayasuriya',
    email: 'saman.j@example.com',
    status: 'accept',
    partySize: 1,
    dietary: [],
    message: 'Cannot wait for the champagne toast and reunion under the glass conservatory!',
    createdAt: '2025-07-16T18:40:00Z'
  },
  {
    id: 'guest-4',
    names: 'Malik & Farah Fernando',
    email: 'malik.fernando@example.com',
    status: 'accept',
    partySize: 2,
    dietary: ['Halal / Kosher'],
    message: 'So incredibly happy for you two! Looking forward to an unforgettable Hudson Valley evening.',
    createdAt: '2025-07-18T11:05:00Z'
  },
  {
    id: 'guest-5',
    names: 'Kavinda & Tharushi Weerakkody',
    email: 'kavinda.w@example.com',
    status: 'decline',
    partySize: 2,
    dietary: [],
    message: 'Heartbroken we will be in Colombo for family duties, but raising our glasses to you both in spirit!',
    createdAt: '2025-07-19T16:30:00Z'
  },
  {
    id: 'guest-6',
    names: 'Oshada & Natalie Peiris',
    email: 'oshada.peiris@example.com',
    status: 'accept',
    partySize: 2,
    dietary: ['Vegan', 'Nut Allergy'],
    message: 'Save us a dance! Can’t wait to celebrate our favorite couple.',
    createdAt: '2025-07-22T20:10:00Z'
  }
];

export const INITIAL_GUESTBOOK_NOTES: GuestbookNote[] = [
  {
    id: 'note-1',
    author: 'Kasun & Dilini',
    location: 'Boston, MA',
    message: 'From college days to this magnificent celebration, witnessing your love unfold has been pure magic. Here’s to a lifetime of adventures together!',
    songRequest: 'Leon Bridges - Beyond',
    date: 'July 12, 2025'
  },
  {
    id: 'note-2',
    author: 'Aunty Sunethra',
    location: 'London, UK',
    message: 'Sending all our love and warmest blessings from overseas. You two bring out the absolute best in one another.',
    songRequest: 'Nat King Cole - L-O-V-E',
    date: 'July 15, 2025'
  },
  {
    id: 'note-3',
    author: 'Malik & Farah',
    location: 'New York, NY',
    message: 'Nadun & Chathurika, your warmth and generosity light up every room. We cannot wait to raise a glass with you under the stars at The Glasshouse.',
    songRequest: 'Earth, Wind & Fire - September',
    date: 'July 18, 2025'
  },
  {
    id: 'note-4',
    author: 'Devinda & Senali',
    location: 'San Francisco, CA',
    message: 'Counting down the days! So excited to fly out and celebrate this unforgettable milestone with you both.',
    songRequest: 'Stevie Wonder - For Once In My Life',
    date: 'July 21, 2025'
  }
];

export interface ScheduleEvent {
  time: string;
  period: string;
  title: string;
  description: string;
  location: string;
  icon: string;
}

export const SCHEDULE_EVENTS: ScheduleEvent[] = [
  {
    time: '4:00 PM',
    period: 'Afternoon Arrival',
    title: 'Guest Arrival & Valet Welcome',
    description: 'Complimentary valet opens at the Main Conservatory gates. Sip welcome lavender lemonade and iced herbal refreshments while strolling through the courtyard gardens.',
    location: 'The Courtyard & West Meadow',
    icon: 'local_bar'
  },
  {
    time: '4:30 PM',
    period: 'Ceremonial Union',
    title: 'Formal Betrothal & Ring Exchange',
    description: 'An intimate ceremony celebrating our promise, family traditions, and exchange of rings surrounded by seasonal florals and soft lilacs.',
    location: 'The Botanical Glass Pavilion',
    icon: 'favorite'
  },
  {
    time: '5:15 PM',
    period: 'Golden Hour',
    title: 'Sunset Champagne & Hors d’oeuvres',
    description: 'Passed artisanal appetizers, curated sparkling wines, and signature cocktails as the golden sunset reflects over the Hudson River.',
    location: 'Upper Garden Terrace',
    icon: 'celebration'
  },
  {
    time: '6:30 PM',
    period: 'Culinary Soirée',
    title: 'Candlelight Seated Dinner',
    description: 'A multi-course seasonal feast prepared with Hudson Valley farm-to-table ingredients, paired with celebratory family toasts and speeches.',
    location: 'The Grand Conservatory Hall',
    icon: 'restaurant'
  },
  {
    time: '8:00 PM',
    period: 'The Festivities',
    title: 'First Dance & Evening Festivities',
    description: 'Live musical ensemble and dance floor opening. Coffee bar, sweet confections, and late-night artisan bites.',
    location: 'Conservatory Dance Floor',
    icon: 'music_note'
  },
  {
    time: '10:30 PM',
    period: 'Grand Finale',
    title: 'Farewell & Sparkler Send-Off',
    description: 'A sparkling pathway send-off celebrating the couple under the Hudson Valley night sky.',
    location: 'Main Porte-Cochère',
    icon: 'flare'
  }
];

export interface HotelRecommendation {
  name: string;
  location: string;
  distance: string;
  description: string;
  bookingCode?: string;
  phone: string;
}

export const RECOMMENDED_HOTELS: HotelRecommendation[] = [
  {
    name: 'The Roundhouse Beacon',
    location: 'Beacon, NY',
    distance: '12 mins from venue',
    description: 'Boutique historic hotel situated beside a rushing waterfall, featuring luxury loft guestrooms and award-winning dining.',
    bookingCode: 'NCENGAGE25',
    phone: '(845) 765-8369'
  },
  {
    name: 'The Beacon Grand',
    location: 'Beacon, NY',
    distance: '14 mins from venue',
    description: 'Warm design-forward accommodations on Main Street, steps away from curated art galleries, cafes, and boutiques.',
    bookingCode: 'NCWEDDING',
    phone: '(845) 838-0024'
  },
  {
    name: 'Hudson Valley River View Inn',
    location: 'Cold Spring, NY',
    distance: '6 mins from venue',
    description: 'Quaint riverside bed & breakfast overlooking Storm King Mountain and the Hudson Highlands.',
    bookingCode: 'Courtesy Block Active',
    phone: '(845) 265-3244'
  }
];
