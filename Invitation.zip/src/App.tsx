import React, { useState, useEffect } from 'react';
import { TabType, GuestRsvp, GuestbookNote, PreviewState } from './types';
import { INITIAL_GUESTS, INITIAL_GUESTBOOK_NOTES } from './data/initialData';
import { Header } from './components/Header';
import { MetadataStrip } from './components/MetadataStrip';
import { RsvpSection } from './components/RsvpSection';
import { DetailsSection } from './components/DetailsSection';
import { ScheduleSection } from './components/ScheduleSection';
import { TravelSection } from './components/TravelSection';
import { RegistryDrawer } from './components/RegistryDrawer';
import { GuestbookModal } from './components/GuestbookModal';
import { VenueModal } from './components/VenueModal';
import { Footer } from './components/Footer';

export default function App() {
  const [currentTab, setCurrentTab] = useState<TabType>('rsvp');
  const [previewState, setPreviewState] = useState<PreviewState>('default');
  const [isRegistryOpen, setIsRegistryOpen] = useState(false);
  const [isGuestbookOpen, setIsGuestbookOpen] = useState(false);
  const [isVenueModalOpen, setIsVenueModalOpen] = useState(false);

  // Local storage persistence for RSVPs
  const [rsvps, setRsvps] = useState<GuestRsvp[]>(() => {
    try {
      const saved = localStorage.getItem('nc_rsvps');
      return saved ? JSON.parse(saved) : INITIAL_GUESTS;
    } catch {
      return INITIAL_GUESTS;
    }
  });

  // Local storage persistence for Guestbook notes
  const [guestbookNotes, setGuestbookNotes] = useState<GuestbookNote[]>(() => {
    try {
      const saved = localStorage.getItem('nc_guestbook');
      return saved ? JSON.parse(saved) : INITIAL_GUESTBOOK_NOTES;
    } catch {
      return INITIAL_GUESTBOOK_NOTES;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('nc_rsvps', JSON.stringify(rsvps));
    } catch {
      // storage unavailable or full
    }
  }, [rsvps]);

  useEffect(() => {
    try {
      localStorage.setItem('nc_guestbook', JSON.stringify(guestbookNotes));
    } catch {
      // storage unavailable or full
    }
  }, [guestbookNotes]);

  const handleRsvpSubmitted = (newRsvp: GuestRsvp) => {
    setRsvps((prev) => [newRsvp, ...prev]);
    // Also if guest left a note, add it to the guestbook
    if (newRsvp.message && newRsvp.message.trim().length > 0) {
      const autoNote: GuestbookNote = {
        id: `note-rsvp-${Date.now()}`,
        author: newRsvp.names,
        message: newRsvp.message,
        date: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric'
        })
      };
      setGuestbookNotes((prev) => [autoNote, ...prev]);
    }
  };

  const handleAddGuestbookNote = (newNote: GuestbookNote) => {
    setGuestbookNotes((prev) => [newNote, ...prev]);
  };

  return (
    <div className="min-h-screen bg-[#fbf8fc] text-[#1b1b1e] flex flex-col font-body selection:bg-[#efdbff] selection:text-[#25123a]">
      {/* 1. Header with Top Bar Contract */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenRegistry={() => setIsRegistryOpen(true)}
        guestCount={rsvps.length}
      />

      <main className="w-full pt-20 flex-1">
        {/* 2. Hero / Headline Section */}
        <section className="relative w-full pt-12 pb-8 px-6 overflow-hidden">
          <div className="max-w-4xl mx-auto text-center relative z-10">
            {/* Florist insignia */}
            <div className="inline-flex items-center justify-center gap-2 text-[#6a5581] mb-3">
              <span className="h-[1px] w-6 bg-[#846d9b]/60"></span>
              <span className="material-symbols-outlined text-[18px]">local_florist</span>
              <span className="h-[1px] w-6 bg-[#846d9b]/60"></span>
            </div>

            <p className="text-xs uppercase tracking-[0.25em] text-[#6a5581] font-semibold mb-2">
              The Joy of Our Engagement
            </p>
            <h1 className="font-headline text-3xl md:text-5xl text-[#1b1b1e] mb-3 font-normal tracking-tight">
              Celebrating Our Engagement
            </h1>
            <p className="font-headline text-base md:text-xl italic text-[#4a454d] max-w-2xl mx-auto font-light">
              Nadun &amp; Chathurika warmly invite you to celebrate their engagement and upcoming union with an evening of music, dining, and shared joy.
            </p>
          </div>
        </section>

        {/* 3. Essential Event Metadata Strip */}
        <MetadataStrip onOpenVenueModal={() => setIsVenueModalOpen(true)} />

        {/* 4. Tab Content Area */}
        {currentTab === 'rsvp' && (
          <RsvpSection
            onRsvpSubmitted={handleRsvpSubmitted}
            onOpenVenueModal={() => setIsVenueModalOpen(true)}
            previewState={previewState}
            setPreviewState={setPreviewState}
          />
        )}

        {currentTab === 'details' && (
          <DetailsSection
            onOpenGuestbook={() => setIsGuestbookOpen(true)}
            onGoToRsvp={() => {
              setCurrentTab('rsvp');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {currentTab === 'schedule' && <ScheduleSection />}

        {currentTab === 'travel' && (
          <TravelSection onOpenVenueModal={() => setIsVenueModalOpen(true)} />
        )}
      </main>

      {/* 5. Minimalist Editorial Footer */}
      <Footer onOpenRegistry={() => setIsRegistryOpen(true)} />

      {/* 6. Interactive Registry Drawer */}
      <RegistryDrawer
        isOpen={isRegistryOpen}
        onClose={() => setIsRegistryOpen(false)}
        rsvps={rsvps}
      />

      {/* 7. Interactive Well-Wishes Guestbook Modal */}
      <GuestbookModal
        isOpen={isGuestbookOpen}
        onClose={() => setIsGuestbookOpen(false)}
        notes={guestbookNotes}
        onAddNote={handleAddGuestbookNote}
      />

      {/* 8. Interactive Venue Directions Modal */}
      <VenueModal
        isOpen={isVenueModalOpen}
        onClose={() => setIsVenueModalOpen(false)}
      />
    </div>
  );
}
